/*
 Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("placeholder","si",{title:"ස්ථාන හීම්කරුගේ ",toolbar:"ස්ථාන හීම්කරු නිර්මාණය කිරීම",name:"Placeholder Name",invalidName:"The placeholder can not be empty and can not contain any of following characters: [, ], \x3c, \x3e",pathName:"placeholder"});